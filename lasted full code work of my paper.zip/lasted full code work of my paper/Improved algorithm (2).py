import time
import pandas as pd
from collections import deque

# 计时开始
start_time = time.time()

class ConceptNode:
    def __init__(self, movie_ids, node_id):
        self.movie_ids = set(movie_ids)  # 电影ID集合，即内涵
        self.user_movies = {}  # 用户对各电影的集合 {user_id: {movie_id}}
        self.extent = set()  # 用户ID集合，即外延
        self.parents = []  # 父节点列表
        self.children = []  # 子节点列表
        self.node_id = node_id  # 节点ID
        self.updated_nodes = set()  # 已更新节点

    def add_user(self, user_id, movie_id):
        # 添加用户和电影
        movie_id = int(movie_id)  # 将电影ID转换为整数
        user_id = int(user_id)  # 将用户ID转换为整数

        if movie_id in self.movie_ids:  # 如果电影ID在内涵中
            if user_id not in self.user_movies:  # 如果用户ID不在用户电影字典中
                self.user_movies[user_id] = set()  # 初始化该用户的电影集合
            self.user_movies[user_id].add(movie_id)  # 添加电影ID到用户的电影集合

    def update_extent(self):
        # 更新节点的外延
        self.extent.clear()  # 清空外延
        for user, movies in self.user_movies.items():  # 遍历每个用户及其电影集合
            if self.movie_ids.issubset(movies):  # 如果内涵是用户电影集合的子集
                self.extent.add(user)  # 将用户添加到外延

    def __repr__(self):
        # 返回节点的字符串表示
        return f'ConceptNode(ID: {self.node_id}, movies: {self.movie_ids}, extent: {self.extent})'


def insert_node_into_concept_lattice(concept_lattice, new_node, updated_nodes=None):
    if updated_nodes is None:
        updated_nodes = set()

    if not concept_lattice:  # 如果概念格为空，无条件插入第一个节点
        concept_lattice.add(new_node)
        print(f"概念格为空，直接插入新节点: {new_node.node_id}, {new_node}")
        return True

    nodes_to_add = []  # 初始化新创建的子节点列表
    inserted = False  # 标记是否已插入

    print(f"开始插入新节点: {new_node.node_id}, {new_node}")  # 打印开始插入新节点信息

    for node in list(concept_lattice):  # 遍历概念格中的每个节点
        if node.node_id in updated_nodes:  # 如果节点已经更新，跳过该节点及其子节点
            continue

        extent_intersection = node.extent.intersection(new_node.extent)  # 计算外延交集
        print(f"检查现有节点（ID: {node.node_id}）: {node}")  # 打印检查的现有节点信息

        if extent_intersection == node.extent:  # 情况1: 外延交集等于现有节点的外延，更新现有节点
            print(f"情况1：更新现有节点（ID: {node.node_id}） {node}")  # 打印情况1信息
            node.movie_ids.update(new_node.movie_ids)  # 合并内涵
            for user, movies in new_node.user_movies.items():  # 遍历新节点的用户电影集合
                if user not in node.user_movies:  # 如果用户不在现有节点的用户电影字典中
                    node.user_movies[user] = movies  # 添加用户的电影集合
                else:
                    node.user_movies[user].update(movies)  # 合并电影集合
            node.update_extent()  # 更新外延
            updated_nodes.add(node.node_id)  # 标记节点已更新
            print(f"Updated node（ID: {node.node_id}）: {node}")  # 打印更新后的节点信息
            inserted = True  # 标记为已插入

        if extent_intersection and extent_intersection != node.extent:  # 情况2: 外延交集不等于现有节点的外延，检查是否需要创建新子节点
            print(f"情况2：外延交集不等于现有节点的外延，检查是否需要创建新子节点 ，现在节点是（ID: {node.node_id}） {node}")  # 打印情况2信息
            if not any(child.extent.issuperset(extent_intersection) for child in node.children):  # 如果没有子节点的外延包含交集
                print(f"需要创建新子节点")  # 打印需要创建新子节点信息
                new_child = ConceptNode(node.movie_ids.union(new_node.movie_ids), len(concept_lattice) + len(nodes_to_add) + 1)  # 创建新子节点
                new_child.extent = extent_intersection  # 设置新子节点的外延
                new_child.user_movies = {
                    user: node.user_movies[user].union(new_node.user_movies[user])
                    for user in extent_intersection if user in node.user_movies and user in new_node.user_movies
                }

                if new_child.movie_ids and new_child.extent:  # 仅在内涵和外延非空时添加新节点
                    new_child.parents.append(node)  # 将当前节点添加为新子节点的父节点
                    node.children.append(new_child)  # 将新子节点添加为当前节点的子节点
                    nodes_to_add.append(new_child)  # 将新子节点添加到新创建的节点列表中
                print(f"创建成功{new_child}")
            else:
                print(f"不需要创建新子节点")  # 打印不需要创建新子节点的信息

    for new_child in nodes_to_add:  # 添加所有新创建的节点到概念格
        concept_lattice.add(new_child)

    print(f"概念格目前包含 {len(concept_lattice)} 个节点")  # 打印概念格的总节点数
    return inserted  # 返回插入标记


def build_concept_lattice(df):
    concept_lattice = set()  # 初始化概念格
    node_queue = deque()  # 初始化节点队列
    all_movie_ids = set(df['movieId'].unique())  # 获取所有唯一的电影ID

    while all_movie_ids:  # 遍历所有电影ID
        selected_movie_ids = [all_movie_ids.pop() for _ in range(2) if all_movie_ids]  # 连续选取两个电影ID
        new_nodes = [ConceptNode([movie_id], len(concept_lattice) + i + 1 + len(node_queue)) for i, movie_id in enumerate(selected_movie_ids)]

        for new_node in new_nodes:
            print(f"处理电影ID: {new_node.movie_ids}")  # 打印当前处理的电影ID

            for _, row in df.iterrows():  # 遍历数据框中的每一行
                user_id = int(row['userId'])  # 获取用户ID
                current_movie_id = int(row['movieId'])  # 获取当前电影ID
                if current_movie_id in new_node.movie_ids:  # 如果当前电影ID等于处理的电影ID
                    new_node.add_user(user_id, current_movie_id)  # 添加用户和电影

            new_node.update_extent()  # 更新新节点的外延

            if not new_node.movie_ids or not new_node.extent:  # 忽略内涵或外延为空的节点
                continue

            print(f"新节点内容: {new_node}")  # 打印新节点内容

        # 构建小概念格
        small_concept_lattice = set()
        for new_node in new_nodes:
            if not small_concept_lattice:
                small_concept_lattice.add(new_node)
            else:
                insert_node_into_concept_lattice(small_concept_lattice, new_node)

        print("小概念格已创建，包含以下节点:")
        for node in small_concept_lattice:
            print(node)

        # 如果主概念格为空，则将小概念格作为主概念格
        if not concept_lattice:
            concept_lattice = small_concept_lattice
        else:
            # 将小概念格的节点插入到主概念格
            updated_nodes = set()
            while small_concept_lattice:
                small_node = next(iter(small_concept_lattice))
                if not insert_node_into_concept_lattice(concept_lattice, small_node, updated_nodes):
                    node_queue.append(small_node)
                small_concept_lattice.remove(small_node)

    print("初始节点插入完成，开始处理队列中的节点...")  # 打印初始节点插入完成的信息

    while node_queue:  # 当队列不为空时
        new_node = node_queue.popleft()  # 弹出队列中的节点
        print(f"重新尝试插入节点: {new_node.node_id}，{new_node}")  # 打印重新尝试插入节点的信息
        if not insert_node_into_concept_lattice(concept_lattice, new_node):  # 重新尝试插入节点到概念格
            node_queue.append(new_node)  # 如果未插入成功，将节点重新加入队列

    return concept_lattice  # 返回构建的概念格


# 初始化概念格节点和读取数据
df = pd.read_csv("ratings_small.csv")  # 读取当前文件夹中的CSV文件

# 构建概念格
concept_lattice = build_concept_lattice(df)  # 调用函数构建概念格
print("所有节点合并完成！")  # 打印所有节点合并完成的信息

# 输出概念格信息
print("打印概念格节点信息：")
for node in concept_lattice:  # 遍历概念格中的每个节点
    print(f"节点信息（ID: {node.node_id}）：")  # 打印节点ID信息
    print(node)  # 打印节点详细信息
    print("父节点: ", [f"ID: {parent.node_id}, movies: {parent.movie_ids}" for parent in node.parents])  # 打印父节点信息
    print("子节点: ", [f"ID: {child.node_id}, movies: {child.movie_ids}" for child in node.children])  # 打印子节点信息
    print()  # 换行

# 计时结束
end_time = time.time()

# 打印运行时间
execution_time = end_time - start_time  # 计算程序运行时间
print(f"程序运行时间: {execution_time:.2f} 秒")  # 打印程序运行时间
