import time
import pandas as pd
from collections import deque

# 计时开始
start_time = time.time()

class ConceptNode:
    def __init__(self, movie_ids, node_id):
        self.movie_ids = set(movie_ids)  # 电影ID集合，即内涵
        self.user_movies = {}  # 用户对各电影的集合 {user_id: {movie_id}}
        self.extent = set()  # 用户ID集合，即外延
        self.parents = []  # 父节点列表
        self.children = []  # 子节点列表
        self.node_id = node_id  # 节点ID

    def add_user(self, user_id, movie_id):
        # 添加用户和电影
        movie_id = int(movie_id)  # 将电影ID转换为整数
        user_id = int(user_id)  # 将用户ID转换为整数

        if movie_id in self.movie_ids:  # 如果电影ID在内涵中
            if user_id not in self.user_movies:  # 如果用户ID不在用户电影字典中
                self.user_movies[user_id] = set()  # 初始化该用户的电影集合
            self.user_movies[user_id].add(movie_id)  # 添加电影ID到用户的电影集合

    def update_extent(self):
        # 更新节点的外延
        self.extent.clear()  # 清空外延
        for user, movies in self.user_movies.items():  # 遍历每个用户及其电影集合
            if self.movie_ids.issubset(movies):  # 如果内涵是用户电影集合的子集
                self.extent.add(user)  # 将用户添加到外延

    def __repr__(self):
        # 返回节点的字符串表示
        return f'ConceptNode(ID: {self.node_id}, movies: {self.movie_ids}, extent: {self.extent})'


def insert_node_into_concept_lattice(concept_lattice, new_node):
    nodes_to_add = []  # 初始化新创建的子节点列表
    inserted = False  # 标记是否已插入

    print(f"开始插入新节点: {new_node.node_id},{new_node}")  # 打印开始插入新节点信息

    for node in list(concept_lattice):  # 遍历概念格中的每个节点
        extent_intersection = node.extent.intersection(new_node.extent)  # 计算外延交集
        print(f"检查现有节点（ID: {node.node_id}）: {node}")  # 打印检查的现有节点信息

        if extent_intersection == node.extent:  # 情况1: 外延交集等于现有节点的外延，更新现有节点
            print(f"情况1：更新现有节点（ID: {node.node_id}） {node}")  # 打印情况1信息
            node.movie_ids.update(new_node.movie_ids)  # 合并内涵
            for user, movies in new_node.user_movies.items():  # 遍历新节点的用户电影集合
                if user not in node.user_movies:  # 如果用户不在现有节点的用户电影字典中
                    node.user_movies[user] = movies  # 添加用户的电影集合
                else:
                    node.user_movies[user].update(movies)  # 合并电影集合
            node.update_extent()  # 更新外延
            print(f"Updated node（ID: {node.node_id}）: {node}")  # 打印更新后的节点信息
            inserted = True  # 标记为已插入
            # break  # 已插入，不需要继续检查

        if extent_intersection and extent_intersection != node.extent:  # 情况2: 外延交集不等于现有节点的外延，检查是否需要创建新子节点
            print(f"情况2：外延交集不等于现有节点的外延，检查是否需要创建新子节点 ，现在节点是（ID: {node.node_id}） {node}")  # 打印情况2信息
            if not any(child.extent.issuperset(extent_intersection) for child in node.children):  # 如果没有子节点的外延包含交集
                print(f"需要创建新子节点")  # 打印需要创建新子节点信息
                new_child = ConceptNode(node.movie_ids.union(new_node.movie_ids), len(concept_lattice) + len(nodes_to_add) + 1)  # 创建新子节点
                new_child.extent = extent_intersection  # 设置新子节点的外延
                new_child.user_movies = {
                    user: node.user_movies[user].union(new_node.user_movies[user])
                    for user in extent_intersection if user in node.user_movies and user in new_node.user_movies
                }

                if new_child.movie_ids and new_child.extent:  # 仅在内涵和外延非空时添加新节点
                    new_child.parents.append(node)  # 将当前节点添加为新子节点的父节点
                    node.children.append(new_child)  # 将新子节点添加为当前节点的子节点
                    nodes_to_add.append(new_child)  # 将新子节点添加到新创建的节点列表中
                    print(f"当前节点的子节点创建完成（ID: {new_child.node_id}）：{new_child}")  # 打印插入的新子节点信息
                    inserted = True  # 标记为已插入
            else:
                print(f"不需要创建新子节点")  # 打印不需要创建新子节点的信息

        # 新增部分：创建新的父节点
        if not any(parent.extent.issuperset(node.extent.union(new_node.extent)) for parent in node.parents):
            print(f"需要创建新父节点")  # 打印需要创建新父节点信息
            new_parent = ConceptNode(node.movie_ids.intersection(new_node.movie_ids), len(concept_lattice) + len(nodes_to_add) + 1)  # 创建新父节点
            new_parent.extent = node.extent.union(new_node.extent)  # 设置新父节点的外延
            new_parent.user_movies = {
                user: node.user_movies[user].union(new_node.user_movies[user])
                for user in node.user_movies if user in new_node.user_movies
            }

            if new_parent.movie_ids and new_parent.extent:  # 仅在内涵和外延非空时添加新节点
                new_parent.children.append(node)  # 将当前节点添加为新父节点的子节点
                node.parents.append(new_parent)  # 将新父节点添加为当前节点的父节点
                concept_lattice.add(new_parent)  # 将新父节点添加到概念格中
                print(f"新父节点创建完成（ID: {new_parent.node_id}）：{new_parent}")  # 打印插入的新父节点信息
                inserted = True  # 标记为已插入

    for new_child in nodes_to_add:  # 添加所有新创建的子节点到概念格
        concept_lattice.add(new_child)
    for new_parent in nodes_to_add:  # 添加所有新创建的子节点到概念格
        concept_lattice.add(new_parent)
    print(f"概念格目前包含 {len(concept_lattice)} 个节点")  # 打印概念格的总节点数
    return inserted  # 返回插入标记


def build_concept_lattice(df):
    concept_lattice = set()  # 初始化概念格
    node_queue = deque()  # 初始化节点队列
    all_movie_ids = set(df['movieId'].unique())  # 获取所有唯一的电影ID
    first_node_inserted = False  # 标记是否已插入第一个节点

    while all_movie_ids:  # 遍历所有电影ID
        movie_id = all_movie_ids.pop()  # 弹出一个电影ID
        new_node = ConceptNode([movie_id], len(concept_lattice) + 1 + len(node_queue))  # 创建新的概念节点

        print(f"处理电影ID: {movie_id}")  # 打印当前处理的电影ID

        for _, row in df.iterrows():  # 遍历数据框中的每一行
            user_id = int(row['userId'])  # 获取用户ID
            current_movie_id = int(row['movieId'])  # 获取当前电影ID
            if current_movie_id == movie_id:  # 如果当前电影ID等于处理的电影ID
                new_node.add_user(user_id, current_movie_id)  # 添加用户和电影

        new_node.update_extent()  # 更新新节点的外延

        if not new_node.movie_ids or not new_node.extent:  # 忽略内涵或外延为空的节点
            continue

        print(f"尝试插入新的节点: {new_node}")  # 打印尝试插入新节点的信息

        if not first_node_inserted:  # 如果还没有插入第一个节点
            concept_lattice.add(new_node)  # 添加新节点到概念格
            first_node_inserted = True  # 标记为已插入第一个节点
            print(f"Added initial node: {new_node.node_id}")  # 打印添加的初始节点信息
        else:
            if not insert_node_into_concept_lattice(concept_lattice, new_node):  # 尝试插入新节点到概念格
                node_queue.append(new_node)  # 如果未插入成功，将新节点加入队列
                print(f"Node queued: {new_node.node_id}")  # 打印加入队列的节点信息

    print("初始节点插入完成，开始处理队列中的节点...")  # 打印初始节点插入完成的信息

    while node_queue:  # 当队列不为空时
        new_node = node_queue.popleft()  # 弹出队列中的节点
        print(f"Reattempting to insert node: {new_node.node_id}{new_node}")  # 打印重新尝试插入节点的信息
        if not insert_node_into_concept_lattice(concept_lattice, new_node):  # 重新尝试插入节点到概念格
            node_queue.append(new_node)  # 如果未插入成功，将节点重新加入队列

    return concept_lattice  # 返回构建的概念格

# 初始化概念格节点和读取数据
df = pd.read_csv("ratings_small.csv")  # 读取当前文件夹中的CSV文件

# 构建概念格
concept_lattice = build_concept_lattice(df)  # 调用函数构建概念格
print("所有节点合并完成！")  # 打印所有节点合并完成的信息

# 输出概念格信息
print("打印概念格节点信息：")
for node in concept_lattice:  # 遍历概念格中的每个节点
    print(f"节点信息（ID: {node.node_id}）：")  # 打印节点ID信息
    print(node)  # 打印节点详细信息
    print("父节点: ", [f"ID: {parent.node_id}, movies: {parent.movie_ids}" for parent in node.parents])  # 打印父节点信息
    print("子节点: ", [f"ID: {child.node_id}, movies: {child.movie_ids}" for child in node.children])  # 打印子节点信息
    print()  # 换行

# 计时结束
end_time = time.time()

# 打印运行时间
execution_time = end_time - start_time  # 计算程序运行时间
print(f"程序运行时间: {execution_time:.2f} 秒")  # 打印程序运行时间
