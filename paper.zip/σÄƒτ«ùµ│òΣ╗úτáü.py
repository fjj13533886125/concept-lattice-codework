import time
import pandas as pd
from collections import deque
import numpy as np

# 计时开始
start_time = time.time()

class ConceptNode:
    def __init__(self, movie_ids, node_id):
        self.movie_ids = set(movie_ids)  # 电影ID集合，即内涵
        self.user_ratings = {}  # 用户对各电影的评分字典 {user_id: {movie_id: rating}}
        self.extent = set()  # 用户ID集合，即外延
        self.ratings = {}  # 评分节点，储存用户ID集合中每个用户对电影集合中所有电影评分的最低值
        self.parents = []  # 父节点列表
        self.children = []  # 子节点列表
        self.E = 0  # 模糊参数E
        self.delta = 0  # 模糊参数δ
        self.node_id = node_id  # 节点ID

    def add_rating(self, user_id, movie_id, rating):
        # 添加用户对某个电影的评分
        movie_id = int(movie_id)  # 将电影ID转换为整数
        user_id = int(user_id)  # 将用户ID转换为整数

        if movie_id in self.movie_ids:  # 如果电影ID在内涵中
            if user_id not in self.user_ratings:  # 如果用户ID不在用户评分字典中
                self.user_ratings[user_id] = {}  # 初始化该用户的评分字典
            self.user_ratings[user_id][movie_id] = rating  # 添加用户对电影的评分

    def update_extent_and_ratings(self):
        # 更新节点的外延和评分节点
        self.extent.clear()  # 清空外延
        self.ratings.clear()  # 清空评分节点
        for user, ratings in self.user_ratings.items():  # 遍历每个用户及其评分
            if self.movie_ids.issubset(ratings.keys()):  # 如果内涵是用户评分电影的子集
                self.extent.add(user)  # 将用户添加到外延
                self.ratings[user] = min(ratings[movie_id] for movie_id in self.movie_ids)  # 设置用户对内涵中所有电影的最低评分

    def calculate_fuzzy_parameters(self):
        # 计算模糊参数E和δ
        if not self.extent:
            self.E = 0
            self.delta = 0
        else:
            memberships = np.array(list(self.ratings.values()))  # 获取评分值
            self.E = np.mean(memberships)  # 计算评分均值
            self.delta = np.std(memberships)  # 计算评分标准差

    def __repr__(self):
        # 返回节点的字符串表示
        return f'ConceptNode(ID: {self.node_id}, movies: {self.movie_ids}, extent: {self.extent}, ratings: {self.ratings}, E: {self.E:.2f}, δ: {self.delta:.2f})'


def insert_node_into_concept_lattice(concept_lattice, new_node):
    nodes_to_add = []  # 初始化新创建的子节点列表
    inserted = False  # 标记是否已插入

    print(f"开始插入新节点: {new_node.node_id},{new_node}")  # 打印开始插入新节点信息

    for node in list(concept_lattice):  # 遍历概念格中的每个节点
        extent_intersection = node.extent.intersection(new_node.extent)  # 计算外延交集
        print(f"检查现有节点（ID: {node.node_id}）: {node}")  # 打印检查的现有节点信息

        if extent_intersection == node.extent:  # 情况1: 外延交集等于现有节点的外延，更新现有节点
            print(f"情况1：更新现有节点（ID: {node.node_id}） {node}")  # 打印情况1信息
            node.movie_ids.update(new_node.movie_ids)  # 合并内涵
            for user, ratings in new_node.user_ratings.items():  # 遍历新节点的用户评分
                if user not in node.user_ratings:  # 如果用户不在现有节点的用户评分字典中
                    node.user_ratings[user] = ratings  # 添加用户的评分
                else:
                    for movie_id, rating in ratings.items():  # 遍历用户的每个评分
                        node.user_ratings[user][movie_id] = min(node.user_ratings[user].get(movie_id, float('inf')), rating)  # 更新评分为最小值
            for user in node.extent:  # 更新评分节点
                node.ratings[user] = min(node.user_ratings[user][movie_id] for movie_id in node.movie_ids)
            node.calculate_fuzzy_parameters()  # 计算模糊参数
            print(f"Updated node（ID: {node.node_id}）: {node}")  # 打印更新后的节点信息
            inserted = True  # 标记为已插入
            break  # 已插入，不需要继续检查

        if extent_intersection and extent_intersection != node.extent:  # 情况2: 外延交集不等于现有节点的外延，检查是否需要创建新子节点
            print(f"情况2：外延交集不等于现有节点的外延，检查是否需要创建新子节点 ，现在节点是（ID: {node.node_id}） {node}")  # 打印情况2信息
            if not any(child.extent.issuperset(extent_intersection) for child in node.children):  # 如果没有子节点的外延包含交集
                print(f"需要创建新子节点")  # 打印需要创建新子节点信息
                new_child = ConceptNode(node.movie_ids.union(new_node.movie_ids), len(concept_lattice) + len(nodes_to_add) + 1)  # 创建新子节点
                new_child.extent = extent_intersection  # 设置新子节点的外延
                new_child.user_ratings = {  # 设置新子节点的用户评分
                    user: {movie_id: min(node.user_ratings[user].get(movie_id, float('inf')),
                                         new_node.user_ratings[user].get(movie_id, float('inf')))
                           for movie_id in new_child.movie_ids}
                    for user in extent_intersection
                }

                for user in new_child.extent:  # 更新新子节点的评分节点
                    new_child.ratings[user] = min(new_child.user_ratings[user][movie_id] for movie_id in new_child.movie_ids)
                if new_child.movie_ids and new_child.extent:  # 仅在内涵和外延非空时添加新节点
                    new_child.calculate_fuzzy_parameters()  # 计算模糊参数
                    new_child.parents.append(node)  # 将当前节点添加为新子节点的父节点
                    node.children.append(new_child)  # 将新子节点添加为当前节点的子节点
                    nodes_to_add.append(new_child)  # 将新子节点添加到新创建的节点列表中
                    print(f"当前节点的子节点创建完成（ID: {new_child.node_id}）：{new_child}")  # 打印插入的新子节点信息
                    inserted = True  # 标记为已插入
            else:
                print(f"不需要创建新子节点")  # 打印不需要创建新子节点的信息

    for new_child in nodes_to_add:  # 添加所有新创建的节点到概念格
        concept_lattice.add(new_child)

    print(f"概念格目前包含 {len(concept_lattice)} 个节点")  # 打印概念格的总节点数
    return inserted  # 返回插入标记


def build_concept_lattice(df):
    concept_lattice = set()  # 初始化概念格
    node_queue = deque()  # 初始化节点队列
    all_movie_ids = set(df['movieId'].unique())  # 获取所有唯一的电影ID
    first_node_inserted = False  # 标记是否已插入第一个节点

    while all_movie_ids:  # 遍历所有电影ID
        movie_id = all_movie_ids.pop()  # 弹出一个电影ID
        new_node = ConceptNode([movie_id], len(concept_lattice) + 1 + len(node_queue))  # 创建新的概念节点

        print(f"处理电影ID: {movie_id}")  # 打印当前处理的电影ID

        for _, row in df.iterrows():  # 遍历数据框中的每一行
            user_id = int(row['userId'])  # 获取用户ID
            current_movie_id = int(row['movieId'])  # 获取当前电影ID
            rating = row['rating']  # 获取评分
            if current_movie_id == movie_id:  # 如果当前电影ID等于处理的电影ID
                new_node.add_rating(user_id, current_movie_id, rating)  # 添加用户对该电影的评分

        new_node.update_extent_and_ratings()  # 更新新节点的外延和评分

        if not new_node.movie_ids or not new_node.extent:  # 忽略内涵或外延为空的节点
            continue

        print(f"尝试插入新的节点: {new_node}")  # 打印尝试插入新节点的信息

        if not first_node_inserted:  # 如果还没有插入第一个节点
            new_node.calculate_fuzzy_parameters()  # 计算模糊参数
            concept_lattice.add(new_node)  # 添加新节点到概念格
            first_node_inserted = True  # 标记为已插入第一个节点
            print(f"Added initial node: {new_node.node_id}")  # 打印添加的初始节点信息
        else:
            if not insert_node_into_concept_lattice(concept_lattice, new_node):  # 尝试插入新节点到概念格
                node_queue.append(new_node)  # 如果未插入成功，将新节点加入队列
                print(f"Node queued: {new_node.node_id}")  # 打印加入队列的节点信息

    print("初始节点插入完成，开始处理队列中的节点...")  # 打印初始节点插入完成的信息

    while node_queue:  # 当队列不为空时
        new_node = node_queue.popleft()  # 弹出队列中的节点
        print(f"Reattempting to insert node: {new_node.node_id}{new_node}")  # 打印重新尝试插入节点的信息
        if not insert_node_into_concept_lattice(concept_lattice, new_node):  # 重新尝试插入节点到概念格
            node_queue.append(new_node)  # 如果未插入成功，将节点重新加入队列

    return concept_lattice  # 返回构建的概念格

def extract_association_rules(concept_lattice, theta, gamma, phi):
    frequent_nodes = []  # 存储频繁节点
    rules = []  # 存储规则

    for node in concept_lattice:  # 遍历概念格中的每个节点
        if node.E > theta and node.delta < gamma:  # 判断节点是否为频繁节点
            frequent_nodes.append(node)  # 添加频繁节点到列表

    for parent in frequent_nodes:  # 遍历每个频繁节点的父节点
        for child in parent.children:  # 遍历父节点的每个子节点
            if child in frequent_nodes:  # 判断子节点是否为频繁节点
                confidence = min(parent.E, child.E) / max(parent.E, child.E)  # 计算置信度
                if confidence >= phi:  # 判断置信度是否满足阈值
                    A = parent.movie_ids  # 获取父节点的电影ID集合
                    B = child.movie_ids - parent.movie_ids  # 获取子节点独有的电影ID集合
                    rule = (A, B, confidence)  # 创建规则
                    rules.append(rule)  # 添加规则到列表

    return rules  # 返回规则列表


# 初始化概念格节点和读取数据
df = pd.read_csv("ratings_small.csv")  # 读取当前文件夹中的CSV文件


# 构建概念格
concept_lattice = build_concept_lattice(df)  # 调用函数构建概念格
print("所有节点合并完成！")  # 打印所有节点合并完成的信息

# 输出概念格信息
print("打印概念格节点信息：")
for node in concept_lattice:  # 遍历概念格中的每个节点
    print(f"节点信息（ID: {node.node_id}）：")  # 打印节点ID信息
    print(node)  # 打印节点详细信息
    print("父节点: ", [f"ID: {parent.node_id}, movies: {parent.movie_ids}" for parent in node.parents])  # 打印父节点信息
    print("子节点: ", [f"ID: {child.node_id}, movies: {child.movie_ids}" for child in node.children])  # 打印子节点信息
    print()  # 换行

# 设置关联规则提取的阈值
theta = 3.2
gamma = 0.1
phi = 0.5

# 提取关联规则
rules = extract_association_rules(concept_lattice, theta, gamma, phi)  # 提取关联规则
print("关联规则提取完成！")  # 打印关联规则提取完成的信息

# 输出关联规则
for A, B, confidence in rules:  # 遍历每个规则
    print(f"规则: {A} => {B}, 置信度: {confidence:.2f}")  # 打印规则详细信息

# 计时结束
end_time = time.time()

# 打印运行时间
execution_time = end_time - start_time  # 计算程序运行时间
print(f"程序运行时间: {execution_time:.2f} 秒")  # 打印程序运行时间
